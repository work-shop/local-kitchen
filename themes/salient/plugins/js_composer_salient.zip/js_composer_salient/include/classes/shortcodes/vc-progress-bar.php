<?php

/* Skills (Bar)
---------------------------------------------------------- */
class WPBakeryShortCode_VC_Progress_Bar extends WPBakeryShortCode {
}